export { default } from "./DishController";
