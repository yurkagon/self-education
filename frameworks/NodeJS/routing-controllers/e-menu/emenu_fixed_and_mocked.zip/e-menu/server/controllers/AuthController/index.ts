export { default } from "./AuthController";
