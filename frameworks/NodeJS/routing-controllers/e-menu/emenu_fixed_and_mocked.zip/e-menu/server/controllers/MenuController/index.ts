export { default } from "./MenuController";
