export { default } from "./RestaurantController";
