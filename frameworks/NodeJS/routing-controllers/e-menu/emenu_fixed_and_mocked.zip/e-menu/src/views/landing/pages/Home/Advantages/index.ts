export { default } from "./Advantages";
