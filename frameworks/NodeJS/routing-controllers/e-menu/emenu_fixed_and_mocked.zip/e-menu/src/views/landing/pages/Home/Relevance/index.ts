export { default } from "./Relevance";
