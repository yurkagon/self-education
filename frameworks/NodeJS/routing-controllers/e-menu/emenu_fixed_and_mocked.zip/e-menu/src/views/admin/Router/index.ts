export { default } from "./Router";
