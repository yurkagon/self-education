import React, { Component } from "react";
import { Helmet } from "react-helmet";

import DishService from "services/DishService";

import RingButton from "views/restaurant/components/RingButton";

import { goBack } from "views/restaurant/utils/LinkBack";

import Page404 from "../Page404";

import PrimaryButton from "../../components/PrimaryButton";
import CloseButton from "../../components/CloseButton";

import { IDishDetailProps, IDishDetailState } from "./types";

import "./style.scss";

class DishDetail extends Component<IDishDetailProps, IDishDetailState> {
  state: IDishDetailState = {
    isLoading: true,
    data: null,
  };

  async componentDidMount() {
    const { match } = this.props;

    try {
      const dish = await DishService.get(match.params.dishId);

      this.setState({ data: dish, isLoading: false });
    } catch {
      this.setState({ isLoading: false });
    }
  }

  onClickFunc = () => {
    // eslint-disable-next-line
    console.log(1);
  };

  render() {
    const { data, isLoading } = this.state;

    // TODO: add spinner
    if (isLoading) return null;

    if (!isLoading && !data) return <Page404 />;

    const dishImage = data.images?.[0] || "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&h=600&fit=crop";

    return (
      <div className="dish-detail">
        <Helmet>
          <title>{data.name.ua}</title>
        </Helmet>

        <CloseButton onClick={() => goBack()} />
        <div className="dish-image-container">
          <img src={dishImage} alt={data.name.ua} className="dish-image" />
        </div>
        <div className="dish-description">
          <div className="dish-header">
            <h2 className="dish-name">{data.name.ua}</h2>
            <div className="dish-price">{data.price.toFixed(2)} грн.</div>
          </div>

          <div className="dish-info">
            <p className="dish-description-text">{data.description}</p>

            <div className="dish-details">
              <div className="detail-item">
                <span className="detail-label">Вага:</span>
                <span className="detail-value">~300 г</span>
              </div>
              <div className="detail-item">
                <span className="detail-label">Час приготування:</span>
                <span className="detail-value">20-25 хв</span>
              </div>
              <div className="detail-item">
                <span className="detail-label">Інгредієнти:</span>
                <span className="detail-value">Свинина, цибуля, зелень, спеції</span>
              </div>
            </div>
          </div>

          <div className="buttons-panel">
            <PrimaryButton
              onClick={this.onClickFunc}
              className="button-align-left"
            >
              Додати до замовлення
            </PrimaryButton>
            <RingButton onClick={() => null} />
          </div>
        </div>
      </div>
    );
  }
}

export default DishDetail;
