export { default } from "./DefaultSEO";
