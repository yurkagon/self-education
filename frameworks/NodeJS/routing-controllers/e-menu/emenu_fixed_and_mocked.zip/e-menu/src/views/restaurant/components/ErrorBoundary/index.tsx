export { default } from "./ErrorBoundary";
