export { default } from "./QRcard";
