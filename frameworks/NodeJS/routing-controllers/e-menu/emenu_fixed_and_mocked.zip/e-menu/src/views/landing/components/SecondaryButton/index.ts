export { default } from "./SecondaryButton";
