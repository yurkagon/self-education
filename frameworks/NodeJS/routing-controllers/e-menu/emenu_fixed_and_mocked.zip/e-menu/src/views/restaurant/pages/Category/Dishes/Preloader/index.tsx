export { default } from "./Preloader";
