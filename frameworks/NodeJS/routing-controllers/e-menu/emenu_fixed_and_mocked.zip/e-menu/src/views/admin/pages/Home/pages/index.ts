import Menu from "./Menu";
import AddRestaurant from "./AddRestaurant";
import TableQRcodes from "./TableQRcodes";
import Feedbacks from "./Feedbacks";
import MyProfile from "./MyProfile";
import MyRestaurant from "./MyRestaurant";

export {
  Menu,
  AddRestaurant,
  TableQRcodes,
  Feedbacks,
  MyProfile,
  MyRestaurant,
};
