export { default } from "./Dishes";
