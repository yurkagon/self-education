import React, { lazy, memo } from "react";

const staticLazy = (dynamicImport: () => Promise<{ default: React.ComponentType<any> }>) => {
  const LazyComponent = lazy(dynamicImport);
  return memo((props) => <LazyComponent {...props} />);
};

export default staticLazy;
