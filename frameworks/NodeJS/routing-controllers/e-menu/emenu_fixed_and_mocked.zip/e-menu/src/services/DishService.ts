import {
  MOCK_DISHES,
  MOCK_RESTAURANT,
  MOCK_USER,
  mockDelay,
} from "./mock/data";

class DishService {
  public async get(id: string): Promise<IDish> {
    await mockDelay();
    const dish = MOCK_DISHES.find((d) => d._id === id);
    if (dish) return { ...dish };
    throw new Error("Dish not found");
  }

  public async create(data: Partial<IDish>): Promise<IDish> {
    await mockDelay();
    const newDish: IDish = {
      _id: `dish-${Date.now()}`,
      ownerId: data.ownerId ?? MOCK_USER._id,
      restaurantId: data.restaurantId ?? MOCK_RESTAURANT._id,
      name: (data.name as IName) ?? { ua: "" },
      description: data.description ?? "",
      price: data.price ?? 0,
      images: data.images ?? [],
      disabled: false,
    };
    return newDish;
  }

  public async delete(id: string): Promise<IDish> {
    await mockDelay();
    const dish = MOCK_DISHES.find((d) => d._id === id) ?? MOCK_DISHES[0];
    return { ...dish };
  }

  public async update(id: string, data: Partial<IDish>): Promise<IDish> {
    await mockDelay();
    const dish = MOCK_DISHES.find((d) => d._id === id) ?? MOCK_DISHES[0];
    return { ...dish, ...data };
  }

  public async getAll(): Promise<IDish[]> {
    await mockDelay();
    return [...MOCK_DISHES];
  }
}

const instance = new DishService();

export default instance;
