import {
  MOCK_FEEDBACKS,
  MOCK_RESTAURANT,
  mockDelay,
} from "./mock/data";

class FeedbackService {
  public async getAllByRestaurantId(restaurantId: string): Promise<IFeedback[]> {
    await mockDelay();
    return restaurantId === MOCK_RESTAURANT._id ? [...MOCK_FEEDBACKS] : [];
  }

  public async create(data: Partial<IFeedback>): Promise<IFeedback> {
    await mockDelay();
    return {
      _id: `fb-${Date.now()}`,
      mark: data.mark ?? 0,
      feedback: data.feedback ?? "",
      restaurantId: data.restaurantId ?? MOCK_RESTAURANT._id,
      createdAt: new Date().toISOString(),
    };
  }

  public async getAll(): Promise<IFeedback[]> {
    await mockDelay();
    return [...MOCK_FEEDBACKS];
  }

  public async get(id: string): Promise<IFeedback> {
    await mockDelay();
    const fb = MOCK_FEEDBACKS.find((f) => f._id === id);
    if (fb) return { ...fb };
    throw new Error("Feedback not found");
  }

  public async delete(id: string): Promise<IFeedback> {
    await mockDelay();
    return MOCK_FEEDBACKS[0];
  }

  public async update(id: string, data: Partial<IFeedback>): Promise<IFeedback> {
    await mockDelay();
    return { ...MOCK_FEEDBACKS[0], ...data };
  }
}

const instance = new FeedbackService();

export default instance;
