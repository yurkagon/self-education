/**
 * Mock data for running the app without backend.
 */

const delay = (ms: number) => new Promise((r) => setTimeout(r, ms));

export const mockDelay = () => delay(300);

export const MOCK_USER: IUser = {
  _id: "user-mock-1",
  email: "user@example.com",
  first_name: "Олександр",
  last_name: "Петренко",
  phone: "+380501234567",
  role: "admin",
  isVerified: true,
  createdAt: new Date(),
  updatedAt: new Date(),
};

export const MOCK_RESTAURANT: IRestaurant = {
  _id: "rest-mock-1",
  name: { ua: "Смачна Хата", en: "Smachna Khata" },
  slug: "smachna-khata",
  table_count: 5,
  ownerId: MOCK_USER._id,
  // @ts-ignore
  logo: "/static/media/cafe.c6747e0877a282fd0017.png",
};

export const MOCK_DISHES: IDish[] = [
  { _id: "dish-1", ownerId: MOCK_USER._id, restaurantId: MOCK_RESTAURANT._id, name: { ua: "Борщ", en: "Borscht" }, description: "Традиційний український борщ з пампушками", price: 85, images: ["https://images.unsplash.com/photo-1547592166-23ac45744acd?w=400&h=300&fit=crop"], disabled: false },
  { _id: "dish-2", ownerId: MOCK_USER._id, restaurantId: MOCK_RESTAURANT._id, name: { ua: "Вареники з картоплею", en: "Varenyky" }, description: "З картоплею та сметаною", price: 75, images: ["https://images.unsplash.com/photo-1621996346565-e3dbc646d9a9?w=400&h=300&fit=crop"], disabled: false },
  { _id: "dish-3", ownerId: MOCK_USER._id, restaurantId: MOCK_RESTAURANT._id, name: { ua: "Котлета по-київськи", en: "Chicken Kyiv" }, description: "Курка з маслом та зеленню", price: 120, images: ["https://images.unsplash.com/photo-1604503468506-a8da13d82791?w=400&h=300&fit=crop"], disabled: false },
  { _id: "dish-4", ownerId: MOCK_USER._id, restaurantId: MOCK_RESTAURANT._id, name: { ua: "Сирники", en: "Syrnyky" }, description: "З сметаною та ягодами", price: 65, images: ["https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?w=400&h=300&fit=crop"], disabled: false },
  { _id: "dish-5", ownerId: MOCK_USER._id, restaurantId: MOCK_RESTAURANT._id, name: { ua: "Голубці", en: "Holubtsi" }, description: "З м'ясом та рисом, томатний соус", price: 95, images: ["https://images.unsplash.com/photo-1603133872878-684f208fb84b?w=400&h=300&fit=crop"], disabled: false },
  { _id: "dish-6", ownerId: MOCK_USER._id, restaurantId: MOCK_RESTAURANT._id, name: { ua: "Сало з часником", en: "Salo" }, description: "З чорним хлібом та гірчицею", price: 55, images: ["https://images.unsplash.com/photo-1509440159596-0249088772ff?w=400&h=300&fit=crop"], disabled: false },
  { _id: "dish-7", ownerId: MOCK_USER._id, restaurantId: MOCK_RESTAURANT._id, name: { ua: "Куліш", en: "Kulish" }, description: "Українська м'ясна юшка з крупом", price: 70, images: ["https://images.unsplash.com/photo-1547592166-23ac45744acd?w=400&h=300&fit=crop"], disabled: false },
  { _id: "dish-8", ownerId: MOCK_USER._id, restaurantId: MOCK_RESTAURANT._id, name: { ua: "Деруни", en: "Deruny" }, description: "Картопляні млинці з сметаною", price: 60, images: ["https://images.unsplash.com/photo-1621996346565-e3dbc646d9a9?w=400&h=300&fit=crop"], disabled: false },
  { _id: "dish-9", ownerId: MOCK_USER._id, restaurantId: MOCK_RESTAURANT._id, name: { ua: "Стейк з яловичини", en: "Beef steak" }, description: "Соковитий стейк середньої прожарки з овочами та соусом", price: 180, images: ["https://recepty.uaplatforma.com.ua/wp-content/uploads/2024/11/steik-1024x694.webp"], disabled: false },
  { _id: "dish-10", ownerId: MOCK_USER._id, restaurantId: MOCK_RESTAURANT._id, name: { ua: "Олів'є", en: "Olivier" }, description: "Салат з ковбасою та овочами", price: 58, images: ["https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=400&h=300&fit=crop"], disabled: false },
  { _id: "dish-11", ownerId: MOCK_USER._id, restaurantId: MOCK_RESTAURANT._id, name: { ua: "Вінегрет", en: "Vinegret" }, description: "Салат з буряком та квасолею", price: 52, images: ["https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=400&h=300&fit=crop"], disabled: false },
  { _id: "dish-12", ownerId: MOCK_USER._id, restaurantId: MOCK_RESTAURANT._id, name: { ua: "Уха", en: "Ukha" }, description: "Рибний суп з коропом та зеленню", price: 88, images: ["https://images.unsplash.com/photo-1547592166-23ac45744acd?w=400&h=300&fit=crop"], disabled: false },
  { _id: "dish-13", ownerId: MOCK_USER._id, restaurantId: MOCK_RESTAURANT._id, name: { ua: "Печеня з яловичини", en: "Beef roast" }, description: "З овочами та соусом", price: 135, images: ["https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=400&h=300&fit=crop"], disabled: false },
  { _id: "dish-14", ownerId: MOCK_USER._id, restaurantId: MOCK_RESTAURANT._id, name: { ua: "Піца з м'ясом", en: "Meat pizza" }, description: "Піца з м'ясом, сиром та овочами", price: 145, images: ["https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=400&h=300&fit=crop"], disabled: false },
  { _id: "dish-15", ownerId: MOCK_USER._id, restaurantId: MOCK_RESTAURANT._id, name: { ua: "Запечена курка", en: "Baked chicken" }, description: "З травами та лимоном", price: 98, images: ["https://images.unsplash.com/photo-1604503468506-a8da13d82791?w=400&h=300&fit=crop"], disabled: false },
  { _id: "dish-16", ownerId: MOCK_USER._id, restaurantId: MOCK_RESTAURANT._id, name: { ua: "Гречаники", en: "Buckwheat cutlets" }, description: "З м'ясним фаршем та сметаною", price: 82, images: ["https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=400&h=300&fit=crop"], disabled: false },
  { _id: "dish-17", ownerId: MOCK_USER._id, restaurantId: MOCK_RESTAURANT._id, name: { ua: "Каша з тушкованим м'ясом", en: "Porridge with stew" }, description: "Гречка або перлівка з яловичиною", price: 72, images: ["https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=400&h=300&fit=crop"], disabled: false },
  { _id: "dish-18", ownerId: MOCK_USER._id, restaurantId: MOCK_RESTAURANT._id, name: { ua: "Компот з сухофруктів", en: "Dried fruit compote" }, description: "Домашній, охолоджений", price: 35, images: ["https://images.unsplash.com/photo-1600271886742-f049cd451bba?w=400&h=300&fit=crop"], disabled: false },
  { _id: "dish-19", ownerId: MOCK_USER._id, restaurantId: MOCK_RESTAURANT._id, name: { ua: "Узвар", en: "Uzvar" }, description: "Напій з сушених яблук та груш", price: 38, images: ["https://images.unsplash.com/photo-1600271886742-f049cd451bba?w=400&h=300&fit=crop"], disabled: false },
  { _id: "dish-20", ownerId: MOCK_USER._id, restaurantId: MOCK_RESTAURANT._id, name: { ua: "Медовик", en: "Honey cake" }, description: "Шарований торт з медом", price: 68, images: ["https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=400&h=300&fit=crop"], disabled: false },
  { _id: "dish-21", ownerId: MOCK_USER._id, restaurantId: MOCK_RESTAURANT._id, name: { ua: "Налисники з сиром", en: "Nalysnyky" }, description: "З творогом та родзинками", price: 62, images: ["https://images.unsplash.com/photo-1528207779346-0a22b22a02f0?w=400&h=300&fit=crop"], disabled: false },
  { _id: "dish-22", ownerId: MOCK_USER._id, restaurantId: MOCK_RESTAURANT._id, name: { ua: "Кава по-українськи", en: "Ukrainian coffee" }, description: "З додаванням спецій", price: 45, images: ["https://images.unsplash.com/photo-1511920170033-f8396924c348?w=400&h=300&fit=crop"], disabled: false },
  { _id: "dish-23", ownerId: MOCK_USER._id, restaurantId: MOCK_RESTAURANT._id, name: { ua: "Чай з шипшини", en: "Rosehip tea" }, description: "Гарячий, з медом", price: 40, images: ["https://images.unsplash.com/photo-1556679343-c7306c1976bc?w=400&h=300&fit=crop"], disabled: false },
  { _id: "dish-24", ownerId: MOCK_USER._id, restaurantId: MOCK_RESTAURANT._id, name: { ua: "Індійський талі", en: "Indian Thali" }, description: "Набір з різних страв: каррі, дал, наан, рис та соуси", price: 110, images: ["https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=400&h=300&fit=crop"], disabled: false },
  { _id: "dish-25", ownerId: MOCK_USER._id, restaurantId: MOCK_RESTAURANT._id, name: { ua: "Стейк з яловичини", en: "Beef steak" }, description: "Соковитий стейк середньої прожарки", price: 180, images: ["https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=400&h=300&fit=crop"], disabled: false },
  { _id: "dish-26", ownerId: MOCK_USER._id, restaurantId: MOCK_RESTAURANT._id, name: { ua: "Ребро ягняти", en: "Lamb ribs" }, description: "Запечене з травами та соусом", price: 165, images: ["https://images.unsplash.com/photo-1529692236671-f1f6cf9683ba?w=400&h=300&fit=crop"], disabled: false },
  { _id: "dish-27", ownerId: MOCK_USER._id, restaurantId: MOCK_RESTAURANT._id, name: { ua: "Котлети з телятини", en: "Veal cutlets" }, description: "Ніжні котлети з гарніром", price: 125, images: ["https://images.unsplash.com/photo-1604503468506-a8da13d82791?w=400&h=300&fit=crop"], disabled: false },
  { _id: "dish-28", ownerId: MOCK_USER._id, restaurantId: MOCK_RESTAURANT._id, name: { ua: "Свинячі реберця", en: "Pork ribs" }, description: "З барбекю соусом", price: 140, images: ["https://images.unsplash.com/photo-1529692236671-f1f6cf9683ba?w=400&h=300&fit=crop"], disabled: false },
  { _id: "dish-29", ownerId: MOCK_USER._id, restaurantId: MOCK_RESTAURANT._id, name: { ua: "Кебаб з баранини", en: "Lamb kebab" }, description: "На шампурах з овочами", price: 130, images: ["https://images.unsplash.com/photo-1529692236671-f1f6cf9683ba?w=400&h=300&fit=crop"], disabled: false },
  { _id: "dish-30", ownerId: MOCK_USER._id, restaurantId: MOCK_RESTAURANT._id, name: { ua: "Куряче філе на грилі", en: "Grilled chicken breast" }, description: "З лимоном та травами", price: 105, images: ["https://images.unsplash.com/photo-1604503468506-a8da13d82791?w=400&h=300&fit=crop"], disabled: false },
  { _id: "dish-31", ownerId: MOCK_USER._id, restaurantId: MOCK_RESTAURANT._id, name: { ua: "Свиняча вирізка", en: "Pork tenderloin" }, description: "З грибним соусом", price: 145, images: ["https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=400&h=300&fit=crop"], disabled: false },
  { _id: "dish-32", ownerId: MOCK_USER._id, restaurantId: MOCK_RESTAURANT._id, name: { ua: "Бараняча ніжка", en: "Lamb leg" }, description: "Запечена з картоплею", price: 175, images: ["https://images.unsplash.com/photo-1529692236671-f1f6cf9683ba?w=400&h=300&fit=crop"], disabled: false },
];

export const MOCK_CATEGORIES_DATA: ICategoryData[] = [
  {
    _id: "cat-1",
    name: { ua: "Перші страви", en: "Soups" },
    dishes: [MOCK_DISHES[0], MOCK_DISHES[6], MOCK_DISHES[11]],
  },
  {
    _id: "cat-2",
    name: { ua: "Гарячі страви", en: "Main dishes" },
    dishes: [MOCK_DISHES[1], MOCK_DISHES[2], MOCK_DISHES[4], MOCK_DISHES[7], MOCK_DISHES[12], MOCK_DISHES[14], MOCK_DISHES[15], MOCK_DISHES[16]],
  },
  {
    _id: "cat-3",
    name: { ua: "Закуски та салати", en: "Starters and salads" },
    dishes: [MOCK_DISHES[5], MOCK_DISHES[9], MOCK_DISHES[10]],
  },
  {
    _id: "cat-4",
    name: { ua: "М'ясо та гриль", en: "Meat and grill" },
    dishes: [MOCK_DISHES[8], MOCK_DISHES[13], MOCK_DISHES[23], MOCK_DISHES[24], MOCK_DISHES[25], MOCK_DISHES[26], MOCK_DISHES[27], MOCK_DISHES[28], MOCK_DISHES[29], MOCK_DISHES[30], MOCK_DISHES[31]],
  },
  {
    _id: "cat-5",
    name: { ua: "Десерти та млинці", en: "Desserts and pancakes" },
    dishes: [MOCK_DISHES[3], MOCK_DISHES[14], MOCK_DISHES[19], MOCK_DISHES[20]],
  },
  {
    _id: "cat-6",
    name: { ua: "Напої", en: "Drinks" },
    dishes: [MOCK_DISHES[17], MOCK_DISHES[18], MOCK_DISHES[21], MOCK_DISHES[22]],
  },
];

/** IMenu uses dishes: string[] (ids) */
export const MOCK_MENU: IMenu = {
  _id: "menu-mock-1",
  restaurantId: MOCK_RESTAURANT._id,
  ownerId: MOCK_USER._id,
  categories: MOCK_CATEGORIES_DATA.map((c) => ({
    _id: c._id,
    name: c.name,
    dishes: c.dishes.map((d) => d._id),
  })),
};

export const MOCK_MENU_DATA: IMenuData = {
  _id: MOCK_MENU._id,
  restaurantId: MOCK_RESTAURANT._id,
  ownerId: MOCK_USER._id,
  categories: [...MOCK_CATEGORIES_DATA],
};

export const MOCK_FEEDBACKS: IFeedback[] = [
  {
    _id: "fb-1",
    mark: 5,
    feedback: "Чудовий ресторан!",
    restaurantId: MOCK_RESTAURANT._id,
    createdAt: new Date().toISOString(),
  },
];
