import { MOCK_RESTAURANT, mockDelay } from "./mock/data";

class RestaurantService {
  public async getBySlug(slug: string): Promise<IRestaurant> {
    await mockDelay();
    if (slug === MOCK_RESTAURANT.slug) return { ...MOCK_RESTAURANT };
    throw new Error("Restaurant not found");
  }

  public async getAllByOwnerId(ownerId: string): Promise<IRestaurant[]> {
    await mockDelay();
    return [{ ...MOCK_RESTAURANT }];
  }

  public async getAll(): Promise<IRestaurant[]> {
    await mockDelay();
    return [{ ...MOCK_RESTAURANT }];
  }

  public async get(id: string): Promise<IRestaurant> {
    await mockDelay();
    if (id === MOCK_RESTAURANT._id) return { ...MOCK_RESTAURANT };
    throw new Error("Restaurant not found");
  }

  public async delete(id: string): Promise<IRestaurant> {
    await mockDelay();
    return { ...MOCK_RESTAURANT };
  }

  public async update(id: string, data: Partial<IRestaurant>): Promise<IRestaurant> {
    await mockDelay();
    return { ...MOCK_RESTAURANT, ...data };
  }

  public async create(data: Partial<IRestaurant>): Promise<IRestaurant> {
    await mockDelay();
    return { ...MOCK_RESTAURANT, ...data, _id: `rest-${Date.now()}` };
  }
}

const instance = new RestaurantService();

export default instance;
