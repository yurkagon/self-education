import TokenStorage from "utils/TokenStorage";
import {
  MOCK_USER,
  mockDelay,
} from "./mock/data";

const tokenStorage = new TokenStorage();

const MOCK_TOKEN = "mock-jwt-token";

class AuthService {
  public async getUser(): Promise<IUser> {
    await mockDelay();
    if (!tokenStorage.get()) throw new Error("Unauthorized");
    return { ...MOCK_USER };
  }

  public async signIn(data: ISignInData): Promise<IUser> {
    await mockDelay();
    tokenStorage.set(MOCK_TOKEN);
    return { ...MOCK_USER };
  }

  public async signUp(data: ISignUpData): Promise<IUser> {
    await mockDelay();
    return { ...MOCK_USER };
  }

  public async confirmEmail(token: string): Promise<IUser> {
    await mockDelay();
    return { ...MOCK_USER };
  }

  public signOut(): void {
    tokenStorage.remove();
  }

  public async updateProfile(data: Partial<IUser>): Promise<IUser> {
    await mockDelay();
    return { ...MOCK_USER, ...data };
  }
}

const instance = new AuthService();

export default instance;
