import {
  MOCK_MENU,
  MOCK_MENU_DATA,
  MOCK_CATEGORIES_DATA,
  MOCK_RESTAURANT,
  mockDelay,
} from "./mock/data";

class MenuService {
  public async getByRestaurantId(restaurantId: string): Promise<IMenu> {
    await mockDelay();
    if (restaurantId === MOCK_RESTAURANT._id) return { ...MOCK_MENU };
    throw new Error("Menu not found");
  }

  public async getMenuDataByRestaurantId(restaurantId: string): Promise<IMenuData> {
    await mockDelay();
    if (restaurantId === MOCK_RESTAURANT._id) return { ...MOCK_MENU_DATA };
    throw new Error("Menu not found");
  }

  public async updateMenu(id: string, data: Partial<IMenu>): Promise<IMenuData> {
    await mockDelay();
    // Ignore incoming categories shape (ICategory[]) and keep mock ICategoryData[]
    const { categories, ...rest } = data;
    return { ...MOCK_MENU_DATA, ...rest };
  }

  public async getCategoryData(
    categoryId: string,
    restaurantId: string
  ): Promise<ICategoryData> {
    await mockDelay();
    const category = MOCK_CATEGORIES_DATA.find((c) => c._id === categoryId);
    if (category) return { ...category };
    throw new Error("Category not found");
  }

  public async getAll(): Promise<IMenu[]> {
    await mockDelay();
    return [{ ...MOCK_MENU }];
  }

  public async get(id: string): Promise<IMenu> {
    await mockDelay();
    return { ...MOCK_MENU };
  }

  public async delete(id: string): Promise<IMenu> {
    await mockDelay();
    return { ...MOCK_MENU };
  }

  public async update(id: string, data: Partial<IMenu>): Promise<IMenu> {
    await mockDelay();
    return { ...MOCK_MENU, ...data };
  }

  public async create(data: Partial<IMenu>): Promise<IMenu> {
    await mockDelay();
    return { ...MOCK_MENU, ...data };
  }
}

const instance = new MenuService();

export default instance;
